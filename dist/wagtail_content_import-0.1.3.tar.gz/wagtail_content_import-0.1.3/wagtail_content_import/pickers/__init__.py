from django.forms.widgets import MediaDefiningClass

class Picker(metaclass=MediaDefiningClass):
    pass
