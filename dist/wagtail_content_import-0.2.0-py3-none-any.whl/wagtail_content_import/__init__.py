__version__ = '0.1a0'

default_app_config = 'wagtail_content_import.apps.WagtailContentImportAppConfig'
