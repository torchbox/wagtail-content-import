class DocumentParser:

    def parse(self):
        raise NotImplementedError
